<?php
/**
 * Italian language file
 *
 * @author   Willy <willygroup@gmail.com>
 */

// custom language strings for the plugin
$lang['page'] = 'Pagina';
$lang['date'] = 'Data';
$lang['user'] = 'User';
$lang['desc'] = 'Descrizione';

//Setup VIM: ex: et ts=2 enc=utf-8 :