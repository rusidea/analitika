<?php
/**
 * Russian language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Aleksandr Selivanov <alexgearbox@gmail.com>
 */

// custom language strings for the plugin
$lang['page'] = 'Страница';
$lang['date'] = 'Дата';
$lang['user'] = 'Участник';
$lang['desc'] = 'Описание';

//Setup VIM: ex: et ts=2 enc=utf-8 :