<?php
/**
 * German language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Esther Brunner <wikidesign@gmail.com>
 */

// custom language strings for the plugin
$lang['page'] = 'Seite';
$lang['date'] = 'Datum';
$lang['user'] = 'Benutzer';
$lang['desc'] = 'Beschreibung';

//Setup VIM: ex: et ts=2 enc=utf-8 :