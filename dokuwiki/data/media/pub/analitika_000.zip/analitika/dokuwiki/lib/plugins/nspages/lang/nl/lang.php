<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Mark Prins <mprins@users.sf.net>
 */
$lang['encoding']              = 'utf-8';
$lang['direction']             = 'ltr';
$lang['doesntexist']           = 'deze naamruimte bestaat niet';
$lang['subcats']               = 'Subnaamruimte:';
$lang['pagesinthiscat']        = 'Pagina\'s in deze naamruimte:';
$lang['continued']             = 'verder';
$lang['nopages']               = 'Geen pagina\'s in deze naamruimte.';
$lang['nosubns']               = 'Geen subnaamruimte.';
