<?php
/**
 * Spanish language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Herman Fabián Sandoval Manrique <hfsandovalm@emzac.com>
 */

// custom language strings for the plugin
$lang['page'] = 'Página';
$lang['date'] = 'Fecha';
$lang['user'] = 'Usuario';
$lang['desc'] = 'Descripción';

//Setup VIM: ex: et ts=2 enc=utf-8 :
