<?php
/**
 * Simplified Chinese language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     haobug <qingxianhao@gmail.com>
 */

// custom language strings for the plugin
$lang['page'] = '页面';
$lang['date'] = '日期';
$lang['user'] = '用户';
$lang['desc'] = '描述';

//Setup VIM: ex: et ts=2 enc=utf-8 :
