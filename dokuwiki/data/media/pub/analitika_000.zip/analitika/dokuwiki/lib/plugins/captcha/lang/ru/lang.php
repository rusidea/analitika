<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Aleksandr Selivanov <alexgearbox@gmail.com>
 * @author Ilya Rozhkov <impeck@ya.ru>
 */
$lang['testfailed']            = 'Извините, код подтверждения введён неверно.';
$lang['fillcaptcha']           = 'Пожалуйста, введите код подтверждения, чтобы доказать, что вы не робот:';
$lang['fillmath']              = 'Ответьте пожалуйста на вопрос, чтобы доказать, что вы человек.';
$lang['soundlink']             = 'Если вы не можете прочитать символы на изображении, загрузите и воспроизведите wav-файл.';
$lang['honeypot']              = 'Пожалуйста, оставьте это поле пустым:';
