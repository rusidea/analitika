<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Aleksandr Selivanov <alexgearbox@gmail.com>
 */
$lang['translations']          = 'Перевод этой страницы';
$lang['outdated']              = 'Этот перевод старее, чем <a href="%s" class="wikilink1">оригинальная страница</a>, и может быть неактуальным.';
$lang['diff']                  = 'Смотрите, что <a href="%s" class="wikilink1">было изменено</a>.';
