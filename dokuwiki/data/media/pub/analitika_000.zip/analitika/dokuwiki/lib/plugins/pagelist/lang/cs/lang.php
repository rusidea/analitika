<?php
/**
 * Czech language file (UTF-8 encoding)
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Lukas Zapletal <lukas.zapletal at gmail dot com>
 */

// custom language strings for the plugin
$lang['page'] = 'Stránka';
$lang['date'] = 'Datum';
$lang['user'] = 'Uživatel';
$lang['desc'] = 'Popis';

//Setup VIM: ex: et ts=2 enc=utf-8 :
