﻿<?php
/**
* Arabic language file
*
* @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
* @author    Muhammad Bashir Al-Noimi <bashir.storm@gmail.com>
*		http://www.hali-sy.com
*/

// custom language strings for the plugin
$lang['page'] = 'الصفحة';
$lang['date'] = 'التاريخ';
$lang['user'] = 'المستخدم';
$lang['desc'] = 'الوصف';

//Setup VIM: ex: et ts=2 enc=utf-8 :