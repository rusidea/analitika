<?php
/**
 * Japanese language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Ikuo Obataya <cxx05051@nifty.com>
 */

// custom language strings for the plugin
$lang['page'] = 'ページ';
$lang['date'] = '日付';
$lang['user'] = 'ユーザー';
$lang['desc'] = '内容';

//Setup VIM: ex: et ts=2 enc=utf-8 :