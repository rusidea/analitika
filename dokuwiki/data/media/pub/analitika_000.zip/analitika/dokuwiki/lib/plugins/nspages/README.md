Plugin for Dokuwiki.

Generate and displays a list of the pages of a namespace.

See https://www.dokuwiki.org/plugin:nspages for more info about installation and usage.
