<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Hideaki SAWADA <chuno@live.jp>
 */
$lang['encoding']              = 'utf-8';
$lang['direction']             = 'ltr';
$lang['doesntexist']           = 'この名前空間は存在しません：';
$lang['subcats']               = 'サブ名前空間：';
$lang['pagesinthiscat']        = 'この名前空間のページ：';
$lang['continued']             = '　の続き';
$lang['nopages']               = 'この名前空間にページがありません。';
$lang['nosubns']               = 'サブ名前空間がありません。';
