<?php
/**
 * Dutch language file.
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Esther Brunner <wikidesign@gmail.com>
 * @author     Mark C. Prins <mprins@users.sf.net>
 */

// custom language strings for the plugin
$lang['page'] = 'Pagina';
$lang['date'] = 'Datum';
$lang['user'] = 'Gebruiker';
$lang['desc'] = 'Beschrijving';

//Setup VIM: ex: et ts=2 enc=utf-8 :
